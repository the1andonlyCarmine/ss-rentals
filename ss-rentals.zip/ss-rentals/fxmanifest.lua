fx_version 'cerulean'
game 'gta5'
lua54 'yes'
description 'ss-rental'
author 'the1andonly_carmine'
version '1.2.0'


client_script 'client/main.lua'
server_script 'server/main.lua'
